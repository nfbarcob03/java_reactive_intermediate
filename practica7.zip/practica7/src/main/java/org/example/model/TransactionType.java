package org.example.model;

public enum TransactionType { CASH_IN, CASH_OUT }