package org.example.model;

public enum TransactionStatus {
    PENDING, POSTED, FAILED
}